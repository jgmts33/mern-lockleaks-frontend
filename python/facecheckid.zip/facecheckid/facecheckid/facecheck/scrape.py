import time
import requests
import os
import sys

photo = sys.argv[1]

tokens = []
with open("tokens.txt", 'r', errors="ignore") as tkns:
    for token1 in tkns.readlines():
        tokens.append(token1)

dirs = os.listdir("pics")
for direc in dirs:
    if str(photo) in direc:
        image_file = os.path.join("pics", direc)

        while True:
            try:
                APITOKEN = tokens.pop(0)
                print(f"token : {APITOKEN}")

                def search_by_face(image_file):
                    site = 'https://facecheck.id'
                    headers = {'accept': 'application/json', 'Authorization': str(APITOKEN).strip()}
                    files = {'images': open(image_file, 'rb'), 'id_search': None}
                    response = requests.post(site+'/api/upload_pic', headers=headers, files=files).json()

                    if response['error']:
                        if "Your image was not recognized as a valid face" in str(response['error']):
                            return "BAD IMAGE", None
                        elif "Invalid API token!" in str(response['error']):
                            return "BAD TOKEN", None
                        else:
                            return f"{response['error']} ({response['code']})", None

                    id_search = response['id_search']
                    print(response['message'] + ' id_search='+id_search)
                    json_data = {'id_search': id_search, 'with_progress': True, 'status_only': False, 'demo': False}

                    while True:
                        response = requests.post(site+'/api/search', headers=headers, json=json_data).json()
                        if response['error']:
                            return f"{response['error']} ({response['code']})", None
                        if response['output']:
                            return None, response['output']['items']
                        time.sleep(1)

                try:
                    error, urls_images = search_by_face(image_file)

                    if urls_images:
                        with open("results.txt", "a") as f:
                            f.write(f"Results for {image_file}:\n")
                            for im in urls_images:
                                score = im['score']
                                url = im['url']
                                image_base64 = im['base64']
                                f.write(f"{score} {url} {image_base64[:32]}...\n")
                    else:
                        print(error)

                    tokens.append(str(APITOKEN).strip())
                    break

                except Exception as e:
                    print(e)

            except Exception as e:
                break

print("done")
