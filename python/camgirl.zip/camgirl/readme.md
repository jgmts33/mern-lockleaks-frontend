# Camgirl Scraper

Script that parses camgirls by username and photo

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install requirements.

```bash
pip install -r requirements.txt
```

## Usage

```bash
#Help page
python camgirl.py -h
#Search by username
python camgirl.py -u "username1,username2"
#Search by photo
python camgirl.py -p "Path_to_image.webp"
```

## Info

**Cost: 80$**

**[Developer's Zelenka](https://zelenka.guru/zzeyy) | [Client's Telegram](https://t.me/trc20bro)**
